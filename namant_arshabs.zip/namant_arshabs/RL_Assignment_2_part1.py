'''
"I (We) certify that the code and data in this assignment were generated independently,
using only the tools and resources defined in the course and that I (we) did not receive
any external help, coaching or contributions during the production of this work."
'''
import gym 

env=gym.make("CartPole-v1")

env.reset()

for i in range(200):
    env.render()
    env.step(env.action_space.sample())
    
env.close()

mountain_car=gym.make("MountainCar-v0")
mountain_car.reset()

for i in range(500):
    mountain_car.render()
    mountain_car.step(mountain_car.action_space.sample())

mountain_car.close()


